import 'package:flutter/material.dart';

class ComingSoon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          actions: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.add_to_photos_rounded),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.person),
            )
          ],
          title: Padding(
            padding: const EdgeInsets.all(15),
            child: Text('Coming Soon',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold)),
          ),
        ),
        backgroundColor: Colors.black,
        body: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(22),
              child: Row(
                children: [
                  Icon(
                    Icons.notifications,
                    color: Colors.white,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text('Notifications',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 160),
                    child: Icon(Icons.arrow_right, color: Colors.white),
                  )
                ],
              ),
            ),
            Image.asset('assets/ageofsam.jpeg', scale: 0.3),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Text('Age Of Samurai',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 120.0),
                  child:
                      Icon(Icons.notification_important, color: Colors.white),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Icon(Icons.info, color: Colors.white),
                ),
              ],
            ),
            Container(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text('Coming Friday',
                    textAlign: TextAlign.start,
                    style: TextStyle(color: Colors.grey)),
              ),
            ),
            Image.asset('assets/senti.jpeg', scale: 1),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Text('Sentinelle',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 175.0),
                  child:
                      Icon(Icons.notification_important, color: Colors.white),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Icon(Icons.info, color: Colors.white),
                ),
              ],
            ),
            Container(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text('Coming Thursday',
                    textAlign: TextAlign.start,
                    style: TextStyle(color: Colors.grey)),
              ),
            )
          ],
        ));
  }
}
