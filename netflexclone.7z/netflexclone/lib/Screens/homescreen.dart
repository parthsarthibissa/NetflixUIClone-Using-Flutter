import 'package:flutter/material.dart';
import 'package:netflexclone/details.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
              backgroundColor: Colors.black,
              leading: Image.asset('assets/netflix.png', scale: 20),
              actions: <Widget>[
                MaterialButton(
                    onPressed: () {},
                    child: Text('TV Shows',
                        style: TextStyle(color: Colors.white, fontSize: 18))),
                Padding(
                  padding: const EdgeInsets.only(right: 15),
                  child: MaterialButton(
                    child: Text('Movies',
                        style: TextStyle(color: Colors.white, fontSize: 18)),
                    onPressed: () {},
                  ),
                ),
                MaterialButton(
                    onPressed: () {},
                    child: Text('My List',
                        style: TextStyle(color: Colors.white, fontSize: 18)))
              ]),
          SliverToBoxAdapter(
              child: Container(
                  height: 250,
                  child: Image.asset('assets/roarofthelion.webp'))),
          SliverToBoxAdapter(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                MaterialButton(
                    onPressed: () {},
                    child: Column(children: <Widget>[
                      Image.asset('assets/add.png',
                          scale: 22, color: Colors.white),
                      Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text('MyList',
                              style: TextStyle(color: Colors.white)))
                    ])),
                Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(5)),
                  child: TextButton.icon(
                    onPressed: null,
                    icon: Image.asset('assets/play.png',
                        scale: 22, color: Colors.black),
                    label: Text('Play',
                        style: TextStyle(color: Colors.black, fontSize: 18)),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(5)),
                  child: TextButton.icon(
                    onPressed: null,
                    icon: Image.asset('assets/info.png',
                        scale: 22, color: Colors.white),
                    label: Text('Info',
                        style: TextStyle(color: Colors.white, fontSize: 18)),
                  ),
                )
              ])),
          SliverToBoxAdapter(
            child: SizedBox(
                child: Column(children: [
              Padding(
                padding: const EdgeInsets.only(top: 25, right: 145),
                child: Text('Continue Watching Parth!',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20)),
              ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15.0),
                    child: SizedBox(
                      width: 100,
                      child: Column(
                        children: <Widget>[
                          SizedBox(
                              height: 150,
                              width: 150,
                              child: Image.asset('assets/avrodh.jpg')),
                          LinearProgressIndicator(
                            value: 50,
                          ),
                          Row(
                            children: <Widget>[
                              IconButton(
                                icon: Image.asset('assets/add.png',
                                    color: Colors.white, scale: 22),
                                onPressed: () {},
                              ),
                              IconButton(
                                icon: Image.asset('assets/info.png',
                                    color: Colors.white, scale: 22),
                                onPressed: () {},
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 15.0),
                    child: SizedBox(
                        width: 100,
                        child: Column(children: <Widget>[
                          SizedBox(
                              height: 150,
                              width: 150,
                              child: Image.asset('assets/roarofthelion2.webp')),
                          LinearProgressIndicator(
                            value: 50,
                          ),
                          Row(
                            children: <Widget>[
                              IconButton(
                                icon: Image.asset('assets/add.png',
                                    color: Colors.white, scale: 22),
                                onPressed: () {},
                              ),
                              IconButton(
                                icon: Image.asset('assets/info.png',
                                    color: Colors.white, scale: 22),
                                onPressed: () {},
                              )
                            ],
                          ),
                        ])),
                  )
                ],
              ),
            ])),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
                height: 220,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 210.0, top: 15),
                      child: Text('Popular on Netflix',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                    ),
                    Expanded(
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                  width: 100,
                                  child: Column(
                                    children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child:
                                              Image.asset('assets/avrodh.jpg')),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                    width: 100,
                                    child: Column(children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child: Image.asset(
                                              'assets/roarofthelion2.webp')),
                                    ])),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                    width: 100,
                                    child: Column(children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child: Image.asset(
                                              'assets/veronica.jpeg')),
                                    ])),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                  width: 100,
                                  child: Column(
                                    children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child:
                                              Image.asset('assets/toc.jpeg')),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                  width: 100,
                                  child: Column(
                                    children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child: Image.asset('assets/red.jpg')),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                  width: 100,
                                  child: Column(
                                    children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child: Image.asset(
                                              'assets/psycho.jpeg')),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 15.0),
                                child: SizedBox(
                                  width: 100,
                                  child: Column(
                                    children: <Widget>[
                                      SizedBox(
                                          height: 150,
                                          width: 150,
                                          child:
                                              Image.asset('assets/curse.jpeg')),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )),
          ),
          SliverToBoxAdapter(
              child: SizedBox(
                  height: 500,
                  child: Column(
                    children: [
                      Text('Availble Now!',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                      Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: SizedBox(
                              height: 250,
                              width: 400,
                              child: Image.asset('assets/gvk.jpeg',
                                  fit: BoxFit.cover))),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5)),
                              child: TextButton.icon(
                                onPressed: () {
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => DetailPage()));
                                },
                                icon: Image.asset('assets/play.png',
                                    scale: 22, color: Colors.black),
                                label: Text('Play',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 18)),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(5)),
                              child: TextButton.icon(
                                onPressed: null,
                                icon: Image.asset('assets/add.png',
                                    scale: 22, color: Colors.white),
                                label: Text('MyList',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 18)),
                              ),
                            ),
                          )
                        ],
                      ),
                    ],
                  )))
        ],
      ),
    );
  }
}
