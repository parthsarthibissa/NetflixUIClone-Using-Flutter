import 'package:flutter/material.dart';

class DownloadsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          actions: [IconButton(icon: Icon(Icons.edit), onPressed: () {})],
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              IconButton(
                icon: Icon(Icons.info),
                onPressed: () {},
              ),
              Text('Smart Downloads'),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('ON',
                    style: TextStyle(
                        color: Colors.blue, fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
        backgroundColor: Colors.black,
        body: Container(
            child: Center(
                child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 150),
              child: Image.asset(
                'assets/downloads.png',
                scale: 3,
                color: Colors.grey,
              ),
            ),
            Padding(
                padding: const EdgeInsets.only(top: 22),
                child: Text(
                    'Movies And TV Shows that you\n        download appear here',
                    style: TextStyle(color: Colors.grey, fontSize: 22))),
            Padding(
              padding: const EdgeInsets.only(top: 125),
              child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(5)),
                  child: MaterialButton(
                      onPressed: () {},
                      child: Text('Find Something to Download',
                          style:
                              TextStyle(color: Colors.black, fontSize: 18)))),
            )
          ],
        ))));
  }
}
