import 'package:flutter/material.dart';
import 'package:netflexclone/Screens/ComingSoon.dart';
import 'package:netflexclone/Screens/Downloads.dart';
import 'package:netflexclone/Screens/homescreen.dart';
import 'package:netflexclone/Screens/search.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'NetflixClone',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primarySwatch: Colors.blue),
        home: Homepage());
  }
}

class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    PageController pageController = PageController();
    void onTap(int pageValue) {
      setState(() {
        selectedIndex = pageValue;
      });
      pageController.jumpToPage(pageValue);
    }

    return Scaffold(
        backgroundColor: Colors.black,
        bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.white,
          backgroundColor: Colors.black87,
          selectedFontSize: 14,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
                icon: Image.asset('assets/home.png',
                    scale: 22, color: Colors.white),
                label: 'Home'),
            BottomNavigationBarItem(
              icon: Image.asset('assets/search.png',
                  scale: 22, color: Colors.white),
              label: 'Search',
            ),
            BottomNavigationBarItem(
                icon: Image.asset('assets/movies.png',
                    scale: 22, color: Colors.white),
                label: 'Movies'),
            BottomNavigationBarItem(
                icon: Image.asset('assets/downloads.png',
                    scale: 22, color: Colors.white),
                label: 'Downloads'),
          ],
          onTap: onTap,
        ),
        body: PageView(
            controller: pageController,
            children: [
              HomeScreen(),
              SearchScreen(),
              ComingSoon(),
              DownloadsScreen(),
            ],
            onPageChanged: (value) {
              setState(() {
                selectedIndex = value;
              });
            }));
  }
}
